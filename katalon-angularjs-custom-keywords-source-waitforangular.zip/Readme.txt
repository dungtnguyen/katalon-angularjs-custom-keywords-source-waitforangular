Note:
This Zip file includes 2 files .jar
 - katalon-angularjs-custom-keywords-source-waitforangular.jar - this is an internal lib. and inlude a customkey word: 
 - ngwebdriver-1.1.4.jar - external lib. - support a method for "waiting for" in Angular application

Before using the custom keyword in internal lib, user has to unzip and copy:
	- The file: "katalon-angularjs-custom-keywords-source-waitforangular.jar" in the Plugins folder in Katalon relevant test project.
	- the file: "ngwebdriver-1.1.4.jar" in the Drivers in Katalon relevant test project